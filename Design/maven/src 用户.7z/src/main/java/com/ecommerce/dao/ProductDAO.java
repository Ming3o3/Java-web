package com.ecommerce.dao;

import com.ecommerce.model.Product;
import java.util.List;

public interface ProductDAO {
    Product getById(Integer productId);
    List<Product> getAll();
    List<Product> getByCategory(String category);
    List<Product> getByMerchant(Integer merchantId);
    void save(Product product);
    void update(Product product);
    void delete(Integer productId);
    List<Product> search(String keyword);
    List<Product> getAllProducts();
    void updateStock(int productId, int quantity);
} 