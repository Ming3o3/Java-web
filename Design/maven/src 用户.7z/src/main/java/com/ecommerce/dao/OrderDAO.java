package com.ecommerce.dao;

import com.ecommerce.model.Order;
import java.util.List;
import java.util.Map;
import java.util.Date;

public interface OrderDAO {
    void save(Order order);
    void update(Order order);
    void delete(Integer orderId);
    Order findById(Integer orderId);
    List<Order> findByCustomerId(Integer customerId);
    List<Order> findAll();
    List<Order> searchOrders(Integer customerId, String keyword, String status, Date startDate, Date endDate);
    boolean canTransitionStatus(String currentStatus, String newStatus);
    Map<String, Object> getOrderStatistics(Integer customerId);
} 