package com.ecommerce.servlet;

import com.ecommerce.dao.OrderDAO;
import com.ecommerce.dao.impl.OrderDAOImpl;
import com.ecommerce.model.Customer;
import com.ecommerce.model.Order;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(urlPatterns = {"/order/detail", "/order/cancel"})
public class OrderDetailServlet extends HttpServlet {
    private OrderDAO orderDAO;

    @Override
    public void init() throws ServletException {
        orderDAO = new OrderDAOImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // 处理订单详情请求
        showOrderDetail(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // 处理取消订单请求
        cancelOrder(request, response);
    }

    private void showOrderDetail(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Customer customer = (Customer) session.getAttribute("customer");
        
        if (customer == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            String orderId = request.getParameter("id");
            if (orderId == null || orderId.trim().isEmpty()) {
                response.sendRedirect(request.getContextPath() + "/order/list");
                return;
            }

            Order order = orderDAO.findById(Integer.parseInt(orderId));
            if (order == null || !order.getCustomerId().equals(customer.getCustomerId())) {
                request.setAttribute("error", "订单不存在或无权访问");
                request.getRequestDispatcher("/WEB-INF/views/order/list.jsp").forward(request, response);
                return;
            }

            request.setAttribute("order", order);
            request.getRequestDispatcher("/WEB-INF/views/order/detail.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", "加载订单详情失败：" + e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/order/list.jsp").forward(request, response);
        }
    }

    private void cancelOrder(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Customer customer = (Customer) session.getAttribute("customer");
        
        if (customer == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            String orderId = request.getParameter("orderId");
            if (orderId == null || orderId.trim().isEmpty()) {
                response.sendRedirect(request.getContextPath() + "/order/list");
                return;
            }

            Order order = orderDAO.findById(Integer.parseInt(orderId));
            if (order == null || !order.getCustomerId().equals(customer.getCustomerId())) {
                request.setAttribute("error", "订单不存在或无权访问");
                request.getRequestDispatcher("/WEB-INF/views/order/list.jsp").forward(request, response);
                return;
            }

            if (!"待发货".equals(order.getStatus())) {
                request.setAttribute("error", "只能取消待发货状态的订单");
                request.getRequestDispatcher("/WEB-INF/views/order/list.jsp").forward(request, response);
                return;
            }

            order.setStatus("已取消");
            orderDAO.update(order);
            response.sendRedirect(request.getContextPath() + "/order/list");
        } catch (Exception e) {
            request.setAttribute("error", "取消订单失败：" + e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/order/list.jsp").forward(request, response);
        }
    }
} 