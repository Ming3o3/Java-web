package com.ecommerce.dao;

import com.ecommerce.model.ReturnGoods;
import java.util.List;

public interface ReturnGoodsDAO {
    void save(ReturnGoods returnGoods);
    void update(ReturnGoods returnGoods);
    void delete(Integer returnId);
    ReturnGoods findById(Integer returnId);
    List<ReturnGoods> findByCustomerId(Integer customerId);
    List<ReturnGoods> findByMerchantId(Integer merchantId);
    List<ReturnGoods> findAll();
    int countPendingReturnsByMerchantId(Integer merchantId);
} 